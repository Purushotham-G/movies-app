import { Box, Container, Grid, Modal, Typography } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";
import User from "./User";

function People() {
 const backgroundColor = "#f4f6fa";
  const [data, setData] = useState("");
  const [selected, setSelected] = useState();
  const [open, setOpen] = useState(false);
  const handleClick = (item) => {
    setOpen(true);
    setSelected(item);
  };
  const handleClose = () => setOpen(false);

  useEffect(() => {
    axios.get(`https://swapi.py4e.com/api/people/`).then((resp) => {
      console.log("result", resp);
      setData(resp?.data);
    });
  }, []);
  return (
    <>
      <Box sx={{ p: 2 }}>
        {data?.results?.map((result) => (
          <Modal open={open} onClose={handleClose}>
            <User
              onClose={() => setOpen(false)}
              name={selected?.name}
              movies={selected?.films}
              species={selected?.species}
              spaceships={selected?.films}
            />
          </Modal>
        ))}

        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            p: 2,
          }}
        >
          <Typography sx={{ fontWeight: "600" }}>
            Arintra Assignment - purushotham
          </Typography>
        </Box>
        <Container sx={{ maxWidth: "1450px !important" }}>
          <Box>
            <Grid container spacing={3}>
              {data?.results?.map((result) => (
                <Grid item xs={12} md={4}>
                  <Box
                    sx={{ cursor: "pointer", borderRadius: "8px" }}
                    onClick={() => handleClick(result)}
                    boxShadow="0px 1px 3px rgb(0 0 0 / 13%)"
                  >
                    <Box
                      component="img"
                      src="./Assets/images/m4.jpg"
                      width="100%"
                      sx={{ aspectRatio: "4/3" }}
                    />
                    <Box
                      sx={{
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        p: 2,
                        background:backgroundColor
                      }}
                    >
                      <Typography sx={{fontWeight:"600"}}>{result?.name}</Typography>
                    </Box>
                  </Box>
                </Grid>
              ))}
            </Grid>
          </Box>
        </Container>
      </Box>
    </>
  );
}

export default People;
