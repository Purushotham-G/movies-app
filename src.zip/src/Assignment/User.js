import { Box, Typography } from "@mui/material";
import axios from "axios";
import React, { useEffect, useState } from "react";

function User({ name, species, movies, spaceships }) {
  const [specieslist, setSpecieslist] = useState([]);
  const [movielist, setMovielist] = useState([]);
  const [spaceshipslist, setSpaceshipslist] = useState([]);

  //specieslist
  useEffect(() => {
    for (let i = 0; i < species?.length; i++) {
      axios.get(species[i]).then((response) => {
        console.log("====>", response);
        const arr1 = [...specieslist, response?.data?.name];
        console.log(arr1);
        setSpecieslist([...specieslist, response?.data?.name]);
      });
    }
  }, []);

  //movielist
  useEffect(() => {
    for (let i = 0; i < movies?.length; i++) {
      axios.get(movies[i]).then((resp) => {
        console.log("ress", resp);
        const arrr = [...movielist, resp?.data?.title];
        console.log(arrr);
        setMovielist([...movielist, resp?.data?.title]);
      });
    }
  }, []);

  //spaceshipslist
  useEffect(() => {
    for (let i = 0; i < spaceships?.length; i++) {
      axios.get([spaceships[i]]).then((ressp) => {
        console.log("$$$$$", ressp);
        const arr2 = [...spaceshipslist, ressp?.data?.spaceships];
        console.log(arr2);
        setSpaceshipslist([...spaceshipslist, ressp?.data?.producer]);
      });
    }
  }, []);
  return (
    <>
      {console.log("species===>", specieslist)}
      {console.log("movie====>", movielist)}
      {console.log("spaceship===>", spaceshipslist)}
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: "500px",
          minHeight: "60vh",
          background: "#fff",
          borderRadius: "8px",
        }}
      >
        <Box>
          <Box
            component="img"
            src="./Assets/images/m3.jpg"
            backgroundSize="contain"
            width="100%"
            sx={{ aspectRatio: "4/2" }}
          />
        </Box>
        <Box sx={{p:3}}>
          <Typography sx={{display:"flex", justifyContent:"center",fontWeight:"600"}}>Output</Typography>
          <Typography>Name :- {name} </Typography>
          <Typography>Species :- {specieslist?.join(",")} </Typography>
          <Typography>Movies :- {movielist?.join(",")} </Typography>
          <Typography>Spaceships :- {spaceshipslist?.join(",")} </Typography>
        </Box>
      </Box>
    </>
  );
}

// > **Name:** Han Solo
// > **Species:** Human
// > **Movies:** Episode IV, Episode V, Episode VI, Episode VII
// > **Spaceships:** Millenium Falcon, Imperial shuttle

export default User;
