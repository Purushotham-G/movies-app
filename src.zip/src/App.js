import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import People from "./Assignment/People";

function App() {
  const routes = (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<People />} />
      </Routes>
    </BrowserRouter>
  );

  return <>{routes}</>;
}

export default App;
